package com.github.spring.service;

public interface UserService {


    public void saveUser(String userName);



    public void init();

    public void  destroy();

}
