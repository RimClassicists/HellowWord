package com.github.spring.constants;

public class Constants {

    public static final String WECHANT_SAN_CODE = "wechat_scan";


}
